function [X, y] = loadFittingDataP1()

% return the data matrix X (100 by 10) and label vector y (100 by 1)

X = importdata('fittingdatap1_x.txt');
y = importdata('fittingdatap1_y.txt');
